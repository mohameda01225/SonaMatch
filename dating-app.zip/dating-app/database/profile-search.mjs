import { createHash } from "node:crypto";

const EMBEDDING_DIMENSIONS = 1536;

export const profileSearchSql = `
  SELECT user_id, content,
         embedding OPERATOR(public.<=>) $1::public.vector(1536) AS distance
  FROM app.profile_embeddings
  WHERE user_id <> $2
  ORDER BY embedding OPERATOR(public.<=>) $1::public.vector(1536)
  LIMIT $3
`;

export function validateEmbedding(embedding) {
  if (!Array.isArray(embedding) || embedding.length !== EMBEDDING_DIMENSIONS) {
    throw new TypeError(`Expected an embedding array with ${EMBEDDING_DIMENSIONS} dimensions.`);
  }
  if (!embedding.every((value) => Number.isFinite(value))) {
    throw new TypeError("Embedding values must all be finite numbers.");
  }
}

export async function saveProfileEmbedding(pool, userId, content, embedding, model) {
  validateEmbedding(embedding);
  if (typeof userId !== "string" || userId.length === 0) {
    throw new TypeError("userId is required.");
  }
  if (typeof content !== "string" || content.trim().length === 0) {
    throw new TypeError("content must be a non-empty string.");
  }
  if (typeof model !== "string" || model.trim().length === 0) {
    throw new TypeError("model is required.");
  }

  const contentHash = createHash("sha256").update(content, "utf8").digest("hex");
  await pool.query(
    `INSERT INTO app.profile_embeddings
       (user_id, content, content_sha256, embedding_model, embedding)
     VALUES ($1, $2, decode($3, 'hex'), $4, $5::public.vector(1536))
     ON CONFLICT (user_id) DO UPDATE
       SET content = EXCLUDED.content,
           content_sha256 = EXCLUDED.content_sha256,
           embedding_model = EXCLUDED.embedding_model,
           embedding = EXCLUDED.embedding,
           updated_at = clock_timestamp()`,
    [userId, content, contentHash, model, JSON.stringify(embedding)],
  );
}

export async function searchProfiles(pool, embedding, excludedUserId, limit = 10) {
  validateEmbedding(embedding);
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) {
    throw new RangeError("limit must be an integer from 1 to 100.");
  }
  if (typeof excludedUserId !== "string" || excludedUserId.length === 0) {
    throw new TypeError("excludedUserId is required.");
  }

  const { rows } = await pool.query(profileSearchSql, [
    JSON.stringify(embedding),
    excludedUserId,
    limit,
  ]);
  return rows;
}
