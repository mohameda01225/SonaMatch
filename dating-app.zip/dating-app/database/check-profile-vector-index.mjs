import pg from "pg";
import { profileSearchSql, validateEmbedding } from "./profile-search.mjs";

const { Client } = pg;
const databaseUrl = process.env.DATABASE_URL;
const expectedDatabase = process.env.APP_DATABASE_NAME;

if (!databaseUrl || !expectedDatabase) {
  throw new Error("Set DATABASE_URL and APP_DATABASE_NAME before checking the vector index.");
}

const client = new Client({ connectionString: databaseUrl });

function containsExpectedIndex(plan) {
  if (!plan || typeof plan !== "object") return false;
  if (plan["Index Name"] === "profile_embeddings_embedding_hnsw_idx") return true;
  return Array.isArray(plan.Plans) && plan.Plans.some(containsExpectedIndex);
}

try {
  await client.connect();
  const { rows: [{ current_database: actualDatabase }] } =
    await client.query("SELECT current_database()");
  if (actualDatabase !== expectedDatabase) {
    throw new Error(
      `Refusing to check database "${actualDatabase}"; APP_DATABASE_NAME is "${expectedDatabase}".`,
    );
  }

  const sample = await client.query(`
    SELECT user_id, embedding::text AS embedding
    FROM app.profile_embeddings
    LIMIT 1
  `);
  if (sample.rowCount !== 1) {
    throw new Error("Cannot verify vector index: app.profile_embeddings has no sample embedding.");
  }

  const embedding = JSON.parse(sample.rows[0].embedding);
  validateEmbedding(embedding);
  const explained = await client.query(
    `EXPLAIN (ANALYZE, FORMAT JSON) ${profileSearchSql}`,
    [JSON.stringify(embedding), sample.rows[0].user_id, 10],
  );
  const planDocument = explained.rows[0]["QUERY PLAN"];
  const plan = Array.isArray(planDocument) ? planDocument[0].Plan : planDocument.Plan;

  if (!containsExpectedIndex(plan)) {
    throw new Error(
      "Profile semantic search did not use profile_embeddings_embedding_hnsw_idx; refusing scan fallback.",
    );
  }
  console.log(`Verified ${profileSearchSql.trim()} uses profile_embeddings_embedding_hnsw_idx.`);
} finally {
  await client.end();
}
