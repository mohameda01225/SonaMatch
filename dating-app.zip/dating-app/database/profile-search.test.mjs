import test from "node:test";
import assert from "node:assert/strict";
import {
  profileSearchSql,
  saveProfileEmbedding,
  searchProfiles,
  validateEmbedding,
} from "./profile-search.mjs";

const embedding = Array(1536).fill(0.25);

test("validates vector dimensions and numeric values", () => {
  assert.doesNotThrow(() => validateEmbedding(embedding));
  assert.throws(() => validateEmbedding([1, 2]), /1536 dimensions/);
  assert.throws(() => validateEmbedding([...embedding.slice(0, -1), Infinity]), /finite numbers/);
});

test("stores vectors and a content hash using a parameterized upsert", async () => {
  let call;
  const pool = {
    async query(sql, values) {
      call = { sql, values };
      return { rowCount: 1 };
    },
  };

  await saveProfileEmbedding(pool, "user-id", "profile text", embedding, "test-model");
  assert.match(call.sql, /INSERT INTO app\.profile_embeddings/);
  assert.match(call.sql, /ON CONFLICT \(user_id\) DO UPDATE/);
  assert.equal(call.values[1], "profile text");
  assert.match(call.values[2], /^[a-f0-9]{64}$/);
  assert.equal(JSON.parse(call.values[4]).length, 1536);
});

test("runs the same parameterized similarity query used by the index check", async () => {
  const expectedRows = [{ user_id: "match", content: "profile", distance: 0.1 }];
  let call;
  const pool = {
    async query(sql, values) {
      call = { sql, values };
      return { rows: expectedRows };
    },
  };

  const rows = await searchProfiles(pool, embedding, "current-user", 5);
  assert.equal(rows, expectedRows);
  assert.equal(call.sql, profileSearchSql);
  assert.deepEqual(call.values, [JSON.stringify(embedding), "current-user", 5]);
  await assert.rejects(() => searchProfiles(pool, embedding, "current-user", 0), /limit must be/);
});
