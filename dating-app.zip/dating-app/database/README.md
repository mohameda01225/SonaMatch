# Database persistence

The migrations target PostgreSQL and create application tables in `app`, with migration history
and the migration lock in `app_meta`. The runner connects to one database, compares its actual
name with `APP_DATABASE_NAME`, and refuses to migrate PostgreSQL's standard system databases.
It does not create or switch databases.

## Requirements

- PostgreSQL 13 or later (`gen_random_uuid()` is used for generated identifiers).
- The `pgvector` extension available to the database server. Vector support is provided by this
  extension; PostgreSQL does not provide the `vector` type in core.
- Node.js and the `pg` dependency declared in this directory's `package.json`.

The last migration fails explicitly if the server does not have pgvector or cannot create the
extension. `profile_embeddings.embedding` uses 1536 dimensions. Keep that dimension aligned with
the selected embedding model; changing it requires a new migration and rebuilding the vector index.

## Run

From this directory, install the declared dependency, then run:

```sh
DATABASE_URL='postgresql://...' APP_DATABASE_NAME='your_app_database' npm run migrate
```

Each unapplied migration runs in its own transaction. The runner obtains a PostgreSQL advisory lock
and records the applied filename and SHA-256 checksum in `app_meta.migration_history` in the same
transaction as the migration. Failed migrations roll back and are safe to retry. An applied file
whose checksum changes is rejected; add a new ordered migration instead. The persistent lock
record in `app_meta.migration_locks` is cleared on exit, while the advisory lock is released by
PostgreSQL if the process or connection terminates.

The migrations create identity/profile, dating discovery, social, messaging, live room,
wallet/gifting, agency, notification, moderation, audit, leaderboard, and profile-semantic-search tables. Sensitive
verification media is represented by an object-storage key rather than stored as raw biometric
data in PostgreSQL.

## Profile semantic search

`profile-search.mjs` contains the exact parameterized query used by the data-access function
`searchProfiles`. Persist profile embeddings as JSON arrays so PostgreSQL can cast them to
`vector(1536)`. After the table contains at least one profile embedding, check the actual query
plan with:

```sh
DATABASE_URL='postgresql://...' APP_DATABASE_NAME='your_app_database' npm run check:vector-index
```

The check executes the application query under `EXPLAIN ANALYZE` and throws unless the plan names
`profile_embeddings_embedding_hnsw_idx`. Thus it fails rather than accepting a sequential-scan
fallback. The optimizer may reasonably choose a scan for a very small table; this check is intended
as an index-usage gate on a representative dataset.
