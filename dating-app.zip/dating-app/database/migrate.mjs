import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const { Client } = pg;
const databaseUrl = process.env.DATABASE_URL;
const expectedDatabase = process.env.APP_DATABASE_NAME;
const here = dirname(fileURLToPath(import.meta.url));

if (!databaseUrl || !expectedDatabase) {
  throw new Error("Set DATABASE_URL and APP_DATABASE_NAME before running migrations.");
}

if (["postgres", "template0", "template1"].includes(expectedDatabase.toLowerCase())) {
  throw new Error(`Refusing to run application migrations against system database "${expectedDatabase}".`);
}

const client = new Client({ connectionString: databaseUrl });
let lockAcquired = false;

try {
  await client.connect();
  await client.query("SET lock_timeout = '30s'");
  await client.query("SET statement_timeout = '5min'");

  const { rows: [{ current_database: actualDatabase }] } =
    await client.query("SELECT current_database()");
  if (actualDatabase !== expectedDatabase) {
    throw new Error(
      `Refusing to migrate database "${actualDatabase}"; APP_DATABASE_NAME is "${expectedDatabase}".`,
    );
  }

  const { rows: lockRows } = await client.query(
    "SELECT pg_try_advisory_lock(811234099, 1) AS acquired",
  );
  if (!lockRows[0].acquired) {
    throw new Error("Another migration process currently holds the application migration lock.");
  }
  lockAcquired = true;

  await client.query("BEGIN");
  try {
    await client.query("CREATE SCHEMA IF NOT EXISTS app_meta");
    await client.query(`
      CREATE TABLE IF NOT EXISTS app_meta.migration_history (
        migration_name text PRIMARY KEY,
        checksum char(64) NOT NULL,
        applied_at timestamptz NOT NULL DEFAULT clock_timestamp()
      )
    `);
    await client.query(`
      CREATE TABLE IF NOT EXISTS app_meta.migration_locks (
        lock_name text PRIMARY KEY,
        owner_pid integer NOT NULL,
        acquired_at timestamptz NOT NULL DEFAULT clock_timestamp()
      )
    `);
    await client.query(
      `INSERT INTO app_meta.migration_locks (lock_name, owner_pid)
       VALUES ('schema-migrations', pg_backend_pid())
       ON CONFLICT (lock_name) DO UPDATE
         SET owner_pid = EXCLUDED.owner_pid, acquired_at = clock_timestamp()`,
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  }

  const migrationDirectory = join(here, "migrations");
  const migrationNames = (await readdir(migrationDirectory))
    .filter((name) => /^\d{4}_[a-z0-9_]+\.sql$/.test(name))
    .sort();

  if (migrationNames.length === 0) {
    throw new Error("No ordered SQL migrations found.");
  }
  const versions = migrationNames.map((name) => Number(name.slice(0, 4)));
  if (versions.some((version, index) => version !== index + 1)) {
    throw new Error("Migration files must be contiguous and start at 0001.");
  }

  const applied = await client.query("SELECT migration_name FROM app_meta.migration_history");
  const localNames = new Set(migrationNames);
  const missingFiles = applied.rows
    .map((row) => row.migration_name)
    .filter((name) => !localNames.has(name));
  if (missingFiles.length > 0) {
    throw new Error(`Applied migration files are missing locally: ${missingFiles.join(", ")}.`);
  }

  for (const migrationName of migrationNames) {
    const sql = await readFile(join(migrationDirectory, migrationName), "utf8");
    const checksum = createHash("sha256").update(sql).digest("hex");
    const { rows } = await client.query(
      "SELECT checksum FROM app_meta.migration_history WHERE migration_name = $1",
      [migrationName],
    );

    if (rows.length > 0) {
      if (rows[0].checksum.trim() !== checksum) {
        throw new Error(`Applied migration ${migrationName} was modified; add a new migration instead.`);
      }
      continue;
    }

    await client.query("BEGIN");
    try {
      await client.query(sql);
      await client.query(
        `INSERT INTO app_meta.migration_history (migration_name, checksum)
         VALUES ($1, $2)`,
        [migrationName, checksum],
      );
      await client.query("COMMIT");
      console.log(`Applied ${migrationName}`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Migration ${migrationName} failed and was rolled back.`, { cause: error });
    }
  }

  const validation = await client.query(`
    SELECT table_name
    FROM unnest(ARRAY[
      'users', 'auth_identities', 'auth_sessions', 'user_roles', 'user_profiles', 'profile_interests',
      'user_verifications', 'verification_events', 'user_follows', 'user_blocks', 'posts',
      'post_media', 'comments', 'likes', 'conversations', 'conversation_members', 'messages',
      'message_read_receipts', 'rooms', 'room_participants', 'room_events', 'room_rankings',
      'wallet_accounts', 'wallet_transactions', 'wallet_entries', 'recharge_transactions',
      'gifts', 'agencies', 'agency_hosts', 'host_performance', 'notifications', 'push_tokens',
      'moderation_reports', 'moderation_flags', 'admin_actions', 'admin_audit_logs',
      'leaderboard_records', 'profile_embeddings', 'profile_swipes', 'matches'
    ]::text[]) AS required(table_name)
    WHERE to_regclass(format('app.%I', table_name)) IS NULL
  `);
  if (validation.rowCount > 0) {
    throw new Error(
      `Post-migration validation failed; missing app tables: ${validation.rows.map((row) => row.table_name).join(", ")}.`,
    );
  }
  const vectorValidation = await client.query(`
    SELECT
      EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'vector') AS extension_exists,
      EXISTS (
        SELECT 1 FROM pg_indexes
        WHERE schemaname = 'app'
          AND tablename = 'profile_embeddings'
          AND indexname = 'profile_embeddings_embedding_hnsw_idx'
          AND indexdef ILIKE '%USING hnsw%'
          AND indexdef ILIKE '%vector_cosine_ops%'
      ) AS index_exists
  `);
  if (!vectorValidation.rows[0].extension_exists || !vectorValidation.rows[0].index_exists) {
    throw new Error("Post-migration validation failed; pgvector extension or cosine HNSW index is missing.");
  }

  console.log(`Migrations verified for database "${actualDatabase}".`);
} finally {
  if (lockAcquired) {
    try {
      await client.query(`
        DO $$
        BEGIN
          IF to_regclass('app_meta.migration_locks') IS NOT NULL THEN
            DELETE FROM app_meta.migration_locks
            WHERE lock_name = 'schema-migrations' AND owner_pid = pg_backend_pid();
          END IF;
        END
        $$
      `);
    } finally {
      await client.query("SELECT pg_advisory_unlock(811234099, 1)");
    }
  }
  await client.end();
}
