CREATE TABLE IF NOT EXISTS app.wallet_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES app.users(id) ON DELETE RESTRICT,
  account_type text NOT NULL CHECK (account_type IN ('user', 'platform', 'revenue')),
  currency_code char(3) NOT NULL DEFAULT 'COI',
  balance_coins bigint NOT NULL DEFAULT 0 CHECK (balance_coins >= 0),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'frozen', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((account_type = 'user' AND user_id IS NOT NULL) OR
         (account_type <> 'user' AND user_id IS NULL))
);

CREATE TABLE IF NOT EXISTS app.wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_type text NOT NULL CHECK (
    transaction_type IN ('recharge', 'gift', 'room_earning', 'withdrawal', 'refund', 'bonus', 'commission')
  ),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'posted', 'failed', 'reversed')),
  idempotency_key text NOT NULL UNIQUE,
  external_reference text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  posted_at timestamptz
);

CREATE TABLE IF NOT EXISTS app.wallet_entries (
  id bigserial PRIMARY KEY,
  transaction_id uuid NOT NULL REFERENCES app.wallet_transactions(id) ON DELETE RESTRICT,
  account_id uuid NOT NULL REFERENCES app.wallet_accounts(id) ON DELETE RESTRICT,
  delta_coins bigint NOT NULL CHECK (delta_coins <> 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (transaction_id, account_id)
);

CREATE TABLE IF NOT EXISTS app.recharge_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  wallet_transaction_id uuid NOT NULL UNIQUE REFERENCES app.wallet_transactions(id) ON DELETE RESTRICT,
  provider text NOT NULL CHECK (provider IN ('apple', 'google_play', 'stripe', 'manual')),
  provider_reference text,
  amount_minor bigint NOT NULL CHECK (amount_minor > 0),
  currency_code char(3) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'succeeded', 'failed', 'refunded')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_reference)
);

CREATE TABLE IF NOT EXISTS app.gifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  receiver_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  room_id uuid REFERENCES app.rooms(id) ON DELETE SET NULL,
  wallet_transaction_id uuid NOT NULL UNIQUE REFERENCES app.wallet_transactions(id) ON DELETE RESTRICT,
  gift_type text NOT NULL,
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  unit_price_coins bigint NOT NULL CHECK (unit_price_coins > 0),
  status text NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'received', 'refunded')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (sender_user_id <> receiver_user_id)
);

CREATE INDEX IF NOT EXISTS wallet_entries_account_created_idx
  ON app.wallet_entries (account_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS wallet_transactions_created_idx
  ON app.wallet_transactions (created_at DESC, id DESC);

DO $$
BEGIN
  IF to_regclass('app.wallet_accounts') IS NULL OR to_regclass('app.wallet_entries') IS NULL
     OR to_regclass('app.gifts') IS NULL THEN
    RAISE EXCEPTION 'Migration 0005 validation failed: required wallet tables are missing';
  END IF;
END
$$;
