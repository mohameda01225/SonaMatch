CREATE OR REPLACE FUNCTION app.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = clock_timestamp();
  RETURN NEW;
END
$$;

DO $$
DECLARE
  target_table text;
BEGIN
  FOREACH target_table IN ARRAY ARRAY[
    'users', 'user_profiles', 'user_verifications', 'posts', 'comments', 'profile_swipes',
    'conversations', 'rooms', 'wallet_accounts', 'agencies', 'host_performance',
    'profile_embeddings'
  ]
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS set_updated_at ON app.%I', target_table);
    EXECUTE format(
      'CREATE TRIGGER set_updated_at BEFORE UPDATE ON app.%I
       FOR EACH ROW EXECUTE FUNCTION app.set_updated_at()',
      target_table
    );
  END LOOP;
END
$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'set_updated_at' AND tgrelid = 'app.user_profiles'::regclass
      AND NOT tgisinternal
  ) THEN
    RAISE EXCEPTION 'Migration 0009 validation failed: updated_at trigger is missing';
  END IF;
END
$$;
