CREATE TABLE IF NOT EXISTS app.user_follows (
  follower_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  followed_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, followed_id),
  CHECK (follower_id <> followed_id)
);

CREATE TABLE IF NOT EXISTS app.user_blocks (
  blocker_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id)
);

CREATE TABLE IF NOT EXISTS app.posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  content text,
  visibility text NOT NULL DEFAULT 'public' CHECK (visibility IN ('public', 'followers', 'private')),
  status text NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'published', 'hidden', 'removed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz,
  CHECK (content IS NOT NULL OR status = 'draft')
);

CREATE TABLE IF NOT EXISTS app.post_media (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES app.posts(id) ON DELETE CASCADE,
  object_key text NOT NULL,
  media_type text NOT NULL CHECK (media_type IN ('image', 'video')),
  sort_order smallint NOT NULL DEFAULT 0 CHECK (sort_order >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (post_id, sort_order)
);

CREATE TABLE IF NOT EXISTS app.comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES app.posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  parent_comment_id uuid REFERENCES app.comments(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (length(trim(content)) > 0),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'hidden', 'removed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  post_id uuid REFERENCES app.posts(id) ON DELETE CASCADE,
  comment_id uuid REFERENCES app.comments(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK ((post_id IS NOT NULL)::integer + (comment_id IS NOT NULL)::integer = 1)
);

CREATE UNIQUE INDEX IF NOT EXISTS likes_user_post_uq
  ON app.likes (user_id, post_id) WHERE post_id IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS likes_user_comment_uq
  ON app.likes (user_id, comment_id) WHERE comment_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS posts_feed_idx ON app.posts (created_at DESC, id DESC)
  WHERE status = 'published' AND deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS posts_user_created_idx ON app.posts (user_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS comments_post_created_idx ON app.comments (post_id, created_at, id);
CREATE INDEX IF NOT EXISTS user_follows_followed_idx
  ON app.user_follows (followed_id, follower_id);
CREATE INDEX IF NOT EXISTS user_blocks_blocked_idx
  ON app.user_blocks (blocked_id, blocker_id);
CREATE INDEX IF NOT EXISTS likes_post_created_idx
  ON app.likes (post_id, created_at DESC) WHERE post_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS likes_comment_created_idx
  ON app.likes (comment_id, created_at DESC) WHERE comment_id IS NOT NULL;

DO $$
BEGIN
  IF to_regclass('app.posts') IS NULL OR to_regclass('app.comments') IS NULL
     OR to_regclass('app.likes') IS NULL THEN
    RAISE EXCEPTION 'Migration 0002 validation failed: required social tables are missing';
  END IF;
END
$$;
