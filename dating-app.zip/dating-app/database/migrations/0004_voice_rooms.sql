CREATE TABLE IF NOT EXISTS app.rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  host_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  title text NOT NULL CHECK (length(trim(title)) > 0),
  description text,
  room_type text NOT NULL DEFAULT 'public' CHECK (room_type IN ('public', 'private', 'invite_only')),
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'live', 'ended', 'cancelled')),
  max_participants integer NOT NULL DEFAULT 10 CHECK (max_participants BETWEEN 1 AND 10000),
  mic_mode text NOT NULL DEFAULT 'moderated' CHECK (mic_mode IN ('open', 'moderated', 'host_only')),
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (ended_at IS NULL OR started_at IS NULL OR ended_at >= started_at)
);

CREATE TABLE IF NOT EXISTS app.room_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES app.rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'listener' CHECK (role IN ('host', 'co_host', 'speaker', 'listener', 'moderator')),
  status text NOT NULL DEFAULT 'joined' CHECK (status IN ('joined', 'muted', 'kicked', 'left', 'banned')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  left_at timestamptz,
  CHECK ((status IN ('left', 'kicked', 'banned')) = (left_at IS NOT NULL))
);

CREATE UNIQUE INDEX IF NOT EXISTS room_participant_active_uq
  ON app.room_participants (room_id, user_id) WHERE left_at IS NULL;
CREATE INDEX IF NOT EXISTS room_participants_active_idx
  ON app.room_participants (room_id, status) WHERE left_at IS NULL;

CREATE TABLE IF NOT EXISTS app.room_events (
  id bigserial PRIMARY KEY,
  room_id uuid NOT NULL REFERENCES app.rooms(id) ON DELETE CASCADE,
  user_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
  event_type text NOT NULL CHECK (
    event_type IN ('join', 'leave', 'gift', 'speaker_change', 'room_start', 'room_end', 'poll', 'moderation')
  ),
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.room_rankings (
  room_id uuid NOT NULL REFERENCES app.rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  rank_position integer NOT NULL CHECK (rank_position > 0),
  score bigint NOT NULL DEFAULT 0 CHECK (score >= 0),
  calculated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (room_id, user_id),
  UNIQUE (room_id, rank_position)
);

CREATE INDEX IF NOT EXISTS rooms_live_idx
  ON app.rooms (created_at DESC, id DESC) WHERE status = 'live';
CREATE INDEX IF NOT EXISTS rooms_host_created_idx
  ON app.rooms (host_user_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS room_events_history_idx
  ON app.room_events (room_id, created_at DESC, id DESC);

DO $$
BEGIN
  IF to_regclass('app.rooms') IS NULL OR to_regclass('app.room_participants') IS NULL
     OR to_regclass('app.room_events') IS NULL THEN
    RAISE EXCEPTION 'Migration 0004 validation failed: required room tables are missing';
  END IF;
END
$$;
