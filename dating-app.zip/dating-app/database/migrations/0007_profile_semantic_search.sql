DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_available_extensions WHERE name = 'vector') THEN
    RAISE EXCEPTION
      'pgvector is not installed on this PostgreSQL server; install the vector extension before migrating';
  END IF;
END
$$;

CREATE EXTENSION IF NOT EXISTS vector;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_extension e
    JOIN pg_namespace n ON n.oid = e.extnamespace
    WHERE e.extname = 'vector' AND n.nspname = 'public'
  ) THEN
    RAISE EXCEPTION 'pgvector must be installed in the public schema for the application query';
  END IF;
END
$$;

CREATE TABLE IF NOT EXISTS app.profile_embeddings (
  user_id uuid PRIMARY KEY REFERENCES app.user_profiles(user_id) ON DELETE CASCADE,
  content text NOT NULL,
  content_sha256 bytea NOT NULL CHECK (octet_length(content_sha256) = 32),
  embedding_model text NOT NULL,
  embedding public.vector(1536) NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS profile_embeddings_embedding_hnsw_idx
  ON app.profile_embeddings USING hnsw (embedding public.vector_cosine_ops);

DO $$
BEGIN
  IF to_regclass('app.profile_embeddings') IS NULL
     OR NOT EXISTS (
       SELECT 1
       FROM pg_indexes
       WHERE schemaname = 'app'
         AND tablename = 'profile_embeddings'
         AND indexname = 'profile_embeddings_embedding_hnsw_idx'
         AND indexdef ILIKE '%USING hnsw%'
         AND indexdef ILIKE '%vector_cosine_ops%'
     )
     OR NOT EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'vector') THEN
    RAISE EXCEPTION 'Migration 0007 validation failed: pgvector table or HNSW index is missing';
  END IF;
END
$$;
