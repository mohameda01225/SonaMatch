CREATE TABLE IF NOT EXISTS app.profile_swipes (
  from_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  to_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  action text NOT NULL CHECK (action IN ('like', 'pass')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (from_user_id, to_user_id),
  CHECK (from_user_id <> to_user_id)
);

CREATE TABLE IF NOT EXISTS app.matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_a_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  user_b_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  matched_at timestamptz NOT NULL DEFAULT now(),
  unmatched_at timestamptz,
  CHECK (user_a_id < user_b_id),
  UNIQUE (user_a_id, user_b_id)
);

CREATE INDEX IF NOT EXISTS profile_swipes_target_idx
  ON app.profile_swipes (to_user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS matches_user_a_idx
  ON app.matches (user_a_id, matched_at DESC) WHERE unmatched_at IS NULL;
CREATE INDEX IF NOT EXISTS matches_user_b_idx
  ON app.matches (user_b_id, matched_at DESC) WHERE unmatched_at IS NULL;

DO $$
BEGIN
  IF to_regclass('app.profile_swipes') IS NULL OR to_regclass('app.matches') IS NULL THEN
    RAISE EXCEPTION 'Migration 0008 validation failed: dating discovery tables are missing';
  END IF;
END
$$;
