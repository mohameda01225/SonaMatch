CREATE TABLE IF NOT EXISTS app.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_type text NOT NULL DEFAULT 'direct' CHECK (conversation_type IN ('direct', 'group')),
  title text,
  created_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.conversation_members (
  conversation_id uuid NOT NULL REFERENCES app.conversations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
  joined_at timestamptz NOT NULL DEFAULT now(),
  left_at timestamptz,
  PRIMARY KEY (conversation_id, user_id)
);

CREATE TABLE IF NOT EXISTS app.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES app.conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  message_type text NOT NULL DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'audio', 'video', 'gift')),
  content text,
  media_object_key text,
  created_at timestamptz NOT NULL DEFAULT now(),
  edited_at timestamptz,
  deleted_at timestamptz,
  CHECK (content IS NOT NULL OR media_object_key IS NOT NULL OR message_type = 'gift')
);

CREATE TABLE IF NOT EXISTS app.message_read_receipts (
  message_id uuid NOT NULL REFERENCES app.messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  read_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

CREATE INDEX IF NOT EXISTS conversation_messages_page_idx
  ON app.messages (conversation_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS conversation_members_user_idx
  ON app.conversation_members (user_id, conversation_id) WHERE left_at IS NULL;

DO $$
BEGIN
  IF to_regclass('app.conversations') IS NULL OR to_regclass('app.messages') IS NULL
     OR to_regclass('app.conversation_members') IS NULL THEN
    RAISE EXCEPTION 'Migration 0003 validation failed: required messaging tables are missing';
  END IF;
END
$$;
