CREATE TABLE IF NOT EXISTS app.agencies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  name text NOT NULL CHECK (length(trim(name)) > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('active', 'pending', 'suspended')),
  commission_rate numeric(5, 2) NOT NULL DEFAULT 0 CHECK (commission_rate BETWEEN 0 AND 100),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.agency_hosts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agency_id uuid NOT NULL REFERENCES app.agencies(id) ON DELETE RESTRICT,
  host_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  role text NOT NULL DEFAULT 'host' CHECK (role IN ('manager', 'host', 'agent')),
  commission_share numeric(5, 2) NOT NULL DEFAULT 0 CHECK (commission_share BETWEEN 0 AND 100),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'blocked')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (agency_id, host_user_id)
);

CREATE TABLE IF NOT EXISTS app.host_performance (
  host_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  agency_id uuid REFERENCES app.agencies(id) ON DELETE SET NULL,
  period_start date NOT NULL,
  rooms_hosted integer NOT NULL DEFAULT 0 CHECK (rooms_hosted >= 0),
  gifts_received_coins bigint NOT NULL DEFAULT 0 CHECK (gifts_received_coins >= 0),
  commission_coins bigint NOT NULL DEFAULT 0 CHECK (commission_coins >= 0),
  performance_score bigint NOT NULL DEFAULT 0 CHECK (performance_score >= 0),
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (host_user_id, period_start)
);

CREATE TABLE IF NOT EXISTS app.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  sender_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
  notification_type text NOT NULL CHECK (
    notification_type IN ('like', 'comment', 'message', 'gift', 'room_invite', 'system', 'verification', 'warning')
  ),
  title text NOT NULL,
  body text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.push_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  token text NOT NULL UNIQUE,
  platform text NOT NULL CHECK (platform IN ('ios', 'android', 'web')),
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.moderation_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  reported_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  report_type text NOT NULL CHECK (
    report_type IN ('spam', 'fraud', 'harassment', 'fake_profile', 'inappropriate_content', 'other')
  ),
  entity_type text CHECK (entity_type IN ('post', 'comment', 'message', 'profile', 'room')),
  entity_id uuid,
  description text,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'reviewing', 'resolved', 'dismissed')),
  resolved_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (reporter_user_id <> reported_user_id)
);

CREATE TABLE IF NOT EXISTS app.moderation_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  entity_type text NOT NULL CHECK (entity_type IN ('post', 'comment', 'message', 'profile', 'room')),
  entity_id uuid NOT NULL,
  reason text NOT NULL CHECK (reason IN ('keyword', 'image_flag', 'suspicious_behavior', 'manual_report')),
  severity text NOT NULL DEFAULT 'low' CHECK (severity IN ('low', 'medium', 'high')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.admin_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  target_user_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
  action_type text NOT NULL CHECK (
    action_type IN ('ban', 'unban', 'warning', 'delete_content', 'verify_user', 'revoke_verification')
  ),
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.admin_audit_logs (
  id bigserial PRIMARY KEY,
  performed_by uuid NOT NULL REFERENCES app.users(id) ON DELETE RESTRICT,
  entity_type text NOT NULL,
  entity_id uuid,
  action text NOT NULL,
  old_value jsonb,
  new_value jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.leaderboard_records (
  id bigserial PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  room_id uuid REFERENCES app.rooms(id) ON DELETE SET NULL,
  metric_type text NOT NULL CHECK (metric_type IN ('gifts', 'rooms', 'engagement', 'earnings')),
  period text NOT NULL CHECK (period IN ('daily', 'weekly', 'monthly', 'all_time')),
  period_start date NOT NULL,
  score numeric(20, 4) NOT NULL DEFAULT 0 CHECK (score >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, room_id, metric_type, period, period_start)
);

CREATE INDEX IF NOT EXISTS notifications_inbox_idx
  ON app.notifications (user_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS moderation_reports_queue_idx
  ON app.moderation_reports (status, created_at);
CREATE INDEX IF NOT EXISTS moderation_reports_target_idx
  ON app.moderation_reports (reported_user_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS moderation_flags_entity_idx
  ON app.moderation_flags (entity_type, entity_id, created_at DESC);
CREATE INDEX IF NOT EXISTS admin_audit_entity_idx
  ON app.admin_audit_logs (entity_type, entity_id, created_at DESC);

DO $$
BEGIN
  IF to_regclass('app.agencies') IS NULL OR to_regclass('app.notifications') IS NULL
     OR to_regclass('app.moderation_reports') IS NULL
     OR to_regclass('app.admin_audit_logs') IS NULL THEN
    RAISE EXCEPTION 'Migration 0006 validation failed: required operations tables are missing';
  END IF;
END
$$;
