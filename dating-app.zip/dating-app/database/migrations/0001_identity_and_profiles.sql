CREATE SCHEMA IF NOT EXISTS app;

CREATE TABLE IF NOT EXISTS app.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);

CREATE TABLE IF NOT EXISTS app.auth_identities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  provider text NOT NULL CHECK (provider IN ('email', 'phone', 'google', 'apple')),
  provider_subject text NOT NULL,
  password_hash text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, provider_subject),
  CHECK ((provider = 'email' AND password_hash IS NOT NULL) OR
         (provider <> 'email' AND password_hash IS NULL))
);

CREATE TABLE IF NOT EXISTS app.auth_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  refresh_token_hash text NOT NULL UNIQUE,
  device_id text,
  device_type text CHECK (device_type IN ('ios', 'android', 'web')),
  ip_address inet,
  user_agent text,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.user_roles (
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'host', 'agency_admin', 'admin', 'super_admin')),
  assigned_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, role)
);

CREATE TABLE IF NOT EXISTS app.user_profiles (
  user_id uuid PRIMARY KEY REFERENCES app.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  first_name text,
  last_name text,
  date_of_birth date,
  gender text CHECK (gender IN ('male', 'female', 'other', 'prefer_not_to_say')),
  bio text,
  country_code char(2),
  city text,
  avatar_url text,
  cover_image_url text,
  relationship_status text CHECK (
    relationship_status IN ('single', 'in_relationship', 'married', 'complicated')
  ),
  is_public boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS user_profiles_username_lower_uq
  ON app.user_profiles (lower(username));

CREATE TABLE IF NOT EXISTS app.profile_interests (
  user_id uuid NOT NULL REFERENCES app.user_profiles(user_id) ON DELETE CASCADE,
  interest text NOT NULL CHECK (length(trim(interest)) > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, interest)
);

CREATE TABLE IF NOT EXISTS app.user_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app.users(id) ON DELETE CASCADE,
  verification_type text NOT NULL CHECK (
    verification_type IN ('selfie', 'identity_document', 'liveness', 'manual_review')
  ),
  status text NOT NULL DEFAULT 'pending' CHECK (
    status IN ('pending', 'approved', 'rejected', 'expired')
  ),
  evidence_object_key text,
  face_match_score numeric(5, 2) CHECK (face_match_score BETWEEN 0 AND 100),
  rejection_reason text,
  reviewed_by uuid REFERENCES app.users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app.verification_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  verification_id uuid NOT NULL REFERENCES app.user_verifications(id) ON DELETE CASCADE,
  actor_user_id uuid REFERENCES app.users(id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('submitted', 'approved', 'rejected', 'expired', 'flagged')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS auth_identities_user_idx ON app.auth_identities (user_id);
CREATE INDEX IF NOT EXISTS auth_sessions_user_expiry_idx
  ON app.auth_sessions (user_id, expires_at DESC) WHERE revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS user_roles_role_idx ON app.user_roles (role, user_id);
CREATE INDEX IF NOT EXISTS user_verifications_review_queue_idx
  ON app.user_verifications (status, created_at);
CREATE INDEX IF NOT EXISTS verification_events_history_idx
  ON app.verification_events (verification_id, created_at DESC);

DO $$
BEGIN
  IF to_regclass('app.users') IS NULL OR to_regclass('app.user_profiles') IS NULL
     OR to_regclass('app.auth_sessions') IS NULL THEN
    RAISE EXCEPTION 'Migration 0001 validation failed: required identity tables are missing';
  END IF;
END
$$;
